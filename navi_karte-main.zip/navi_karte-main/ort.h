#ifndef ORT_H
#define ORT_H
#include<iostream>
#include<string>
#include<QString>
#include<vector>
#include<cmath>
#include<fstream>
#include<iomanip>

using namespace std;

static const double pi = 3.14;
static const double erd_radius = 6371.0;    //in km

class Ort
{
    const int id;
    const double laengengrad;
    const double breitengrad;
    string type;

public:
    Ort();
    virtual ~Ort();
    Ort(double, double);
    int getId()const;
    double getLaengengrad()const;
    double getBreitengrad()const;
    virtual string getType()const ;
    double EntfernungBerechnen(const Ort*);
    virtual string anzeigen() const;
    virtual void setType(char type);
    virtual string getname() {return " ";};
    virtual string getparameters() {return " ";};
};

double inGradUmwandeln(double);

#endif // ORT_H
