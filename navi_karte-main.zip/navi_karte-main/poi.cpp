#include "poi.h"
#include "ort.h"

PoI::PoI()
    :Ort(),kategorie{"kategorie"},bemerkung{"bemerkung"}
{}

PoI::PoI(double laengengrad, double breitengrad, string kategorie, string bemerkung, string name)
    :Ort(laengengrad,breitengrad), kategorie{kategorie},bemerkung{bemerkung}, name{name}
{}

PoI::~PoI(){

}

void PoI::setType(char type){
    Ort::setType(type);
}

string PoI::getKategorie()const{
    return kategorie;
}

string PoI::getBemerkung()const{
    return bemerkung;
}

Ort* PoI::createPoi(){
    double laengengrad{},breitengrad{};
    string kategorie{},bemerkung{};

    cout<<"laengengrad eingeben"<<endl;
    cin>>laengengrad;
    cout<<"breitengrad eingeben"<<endl;
    cin>>breitengrad;

    cout<<"kategorie eingeben"<<endl;
    cin>>kategorie;
    cout<<"bemerkung eingeben"<<endl;
    cin>>bemerkung;

    PoI* p = new PoI(laengengrad,breitengrad,kategorie,bemerkung, name);
    p->setType('p');
    return p;
}

string PoI::anzeigen() const {
    string poianzeigen = name + "     | " + std::to_string(Ort::getBreitengrad()) + "  | " + std::to_string(Ort::getLaengengrad()) + "  | " +  kategorie + ", " + bemerkung + "\n";
    return poianzeigen;
}

string PoI::getparameters(){
    return this->kategorie + ", " + this->bemerkung;
}
