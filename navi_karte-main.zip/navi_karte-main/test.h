#ifndef TEST_H
#define TEST_H

#include <QtTest/QTest>

#include "poi.h"

class Test : public QObject
{
    Q_OBJECT
public:
    explicit Test(QObject *parent = 0);
private slots:
    void test_saarbruecken_cottbus();
    void test_kiel_muenchen();
    void test_duesseldorf_chemnitz();
    void test_bremen_augsburg();
};

#endif // TEST_H
