#ifndef POI_H
#define POI_H

#include "ort.h"
#include <iostream>

using namespace std;

class PoI:public Ort
{
private:
    string kategorie;
    string bemerkung;
    string name;
public:
    PoI();
    PoI(double, double, string, string, string);
    ~PoI();
    Ort* createPoi();
    string getKategorie()const;
    string getBemerkung()const;
    string anzeigen() const override;
    void setType(char type)override;
    string getname() override {return name;};
    string getType()const override {return "PoI";};
    string getparameters() override;
};

#endif // POI_H

