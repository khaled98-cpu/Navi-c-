#ifndef NAVIGATION_H
#define NAVIGATION_H

#include <QMainWindow>
#include <QInputDialog>
#include <iostream>
#include <QApplication>
#include <QMessageBox>

#include <QPlainTextEdit>

//eigene includes
#include "qdynamicbutton.h"
#include "poi.h"
#include "adresse.h"
#include "ort.h"

#include "graph.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Navigation; }
QT_END_NAMESPACE

class Navigation : public QMainWindow
{
    Q_OBJECT

public:
    Navigation(QWidget *parent = nullptr);
    ~Navigation();
    Ui::Navigation* getui(){return ui;};
private slots:
    void neuer_Ort();
    int slotGetNumber();
    void exportASCII();
    void importASCII();
    void ortloeschen();

    void alleOrte();
    void information();
    void entfernung();
    void routing();
private:
    Ui::Navigation *ui;
    std::vector<Ort*>karte;
    std::vector<QDynamicButton*>buttonvec;

    Graph graph;
    bool ort1;
};
#endif // NAVIGATION_H
