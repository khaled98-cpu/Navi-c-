#include "navigation.h"
#include "ui_navigation.h"

Navigation::Navigation(QWidget *parent) //MyClass(int numVertices) : graph(numVertices)
    : QMainWindow(parent)
    , ui(new Ui::Navigation), graph(35)
{
    ui->setupUi(this);

    connect(ui->neuerOrt,SIGNAL(clicked()),this, SLOT(neuer_Ort()));
    connect(ui->import_2,SIGNAL(clicked()),this,SLOT(importASCII()));
    connect(ui->export_2,SIGNAL(clicked()),this,SLOT(exportASCII()));
    connect(ui->information,SIGNAL(clicked()),this,SLOT(information()));
    connect(ui->alleOrte,SIGNAL(clicked()),this,SLOT(alleOrte()));
    connect(ui->entfernung,SIGNAL(clicked()),this,SLOT(entfernung()));
    connect(ui->OrtLoeschen,SIGNAL(clicked()),this,SLOT(ortloeschen()));
    connect(ui->Routing,SIGNAL(clicked()),this,SLOT(routing()));

    ui->Ort1->hide();
    ui->Ort2->hide();
    ui->OrtLoeschen->hide();
    ui->neuerOrt->hide();
    ui->information->hide();
    ui->alleOrte->hide();
    ui->entfernung->hide();
    ui->Routing->hide();
    ui->export_2->hide();

    ui->index1->hide();
    ui->index2->hide();
}

Navigation::~Navigation()
{
    delete ui;
}

double berechnung_laenge(double laenge){
    laenge = ((laenge - 5.866315) * 67.02) + 5;
    return laenge;
}

double berechnung_breite(double breite){
    breite = (((55.1 - breite) / (55.1 - 47.3)) * 830) + 5;
    return breite;
}

void Navigation::neuer_Ort(){
    QDynamicButton *button = new QDynamicButton(this);  // Create a dynamic button object

    bool laenge, breite;
    //poi oder adresse
    QString dif = QInputDialog::getText(this,"Adresse/PoI", "Adresse/PoI");
    if(dif != "Adresse" && dif != "PoI"){
        QMessageBox::information(nullptr, "Fehlermeldung", "Keine gültige Eingabe");
        return;
    }
    //int ID; // aus Ort-Klasse
    QString name = QInputDialog::getText(this,"Name", "Name");
    double laengengrad = QInputDialog::getText(this,"Längengrad", "Längengrad").toDouble(&laenge);
    double breitengrad = QInputDialog::getText(this,"Breitengrad", "Breitengrad").toDouble(&breite);

    if(!laenge || !breite){
        QMessageBox::information(nullptr, "Fehlermeldung", "Keine gültige Eingabe");
        return;
    }

    if(dif == "Adresse"){
        bool post;
        QString strasse = QInputDialog::getText(this,"Straße", "Straße");
        QString hausnummer = QInputDialog::getText(this,"Hausnummer", "Hausnummer");
        int postleitzahl = QInputDialog::getText(this,"Postleitzahl", "Postleitzahl").toInt(&post);
        QString stadt = QInputDialog::getText(this,"Stadt", "Stadt");

        if(!post){
            QMessageBox::information(nullptr, "Fehlermeldung", "Keine gültige Eingabe");
            return;
        }

        Adresse* adresse = new Adresse(laengengrad, breitengrad, strasse.toStdString(), hausnummer.toStdString(), postleitzahl, stadt.toStdString(), name.toStdString());
        karte.push_back(adresse);
    }

    if(dif == "PoI"){
        QString kategorie = QInputDialog::getText(this,"Kategorie", "Kategorie");
        QString bemerkung = QInputDialog::getText(this,"Bemerkung", "Bemerkung");

        PoI* poi = new PoI(laengengrad, breitengrad, kategorie.toStdString() ,bemerkung.toStdString() ,name.toStdString());
        karte.push_back(poi);
    }

    int id = karte.size()-1;
    int smallestid = 0;
    double smallest = karte.at(id)->EntfernungBerechnen(karte.at(0));
    double secondsmallest;
    int secondid;

    for (unsigned int i = 0; i < karte.size() - 1; ++i) {
        double vergleich = karte.at(id)->EntfernungBerechnen(karte.at(i));
        if(vergleich < smallest){
            secondsmallest = smallest;
            secondid = smallestid;
            smallest = vergleich;
            smallestid = i;
        }
        else if(vergleich < secondsmallest && vergleich != smallest){
            secondsmallest = vergleich;
            secondid = i;
        }
    }

    graph.addEdge(id, smallestid, smallest);
    graph.addEdge(id, secondid, secondsmallest);

    QString ausgabe = "Hinzugefügte Verbindungen: \n";
    ausgabe.append(QString::fromStdString(karte.at(smallestid)->getname() + " : ") + QString::number(smallest) +  QString::fromStdString("km \n" + karte.at(secondid)->getname() + " : ") + QString::number(secondsmallest) + "km");
    QMessageBox::information(nullptr, "Hinzugefügte Knaten", ausgabe);

    button->setText(name);

    laengengrad = berechnung_laenge(laengengrad);
    breitengrad = berechnung_breite(breitengrad);

    button->setGeometry(laengengrad,breitengrad, button->width(), 20);

    button->show();

    connect(button, SIGNAL(clicked()), this, SLOT(slotGetNumber()));

    buttonvec.push_back(button);
}

int Navigation::slotGetNumber()
{
    //auswahl2 ist oben
    QDynamicButton *button = (QDynamicButton*) sender();

    if(!ort1){
        ui->auswahl2->setText(QString::fromStdString(karte.at(button->getID()-1)->getname()));
        ui->index2->setText(QString::number(button->getID()-1));

        ort1 = true;
    }
    else{
        ui->auswahl->setText(QString::fromStdString(karte.at(button->getID()-1)->getname()));
        ui->index1->setText(QString::number(button->getID()-1));

        ort1 = false;
    }

    return button->getID();
}

void Navigation::exportASCII(){
    if(karte.empty()){
        QMessageBox::information(nullptr, "Fehlermeldung", "Es wurden noch keine Orte angelegt");
        return;
    }

    QString QFilename = QInputDialog::getText(this,"Dateiname", "Dateiname mit Datepfad angeben");
    std::string filename = QFilename.toStdString(); //(/home/stud/Uni/Ablage_Test/export.txt)
    std::fstream file_out;

    file_out.open(filename, std::ios_base::out);
    if(!file_out.is_open()){
        QMessageBox::information(nullptr, "Fehlermeldung", "Datei kann nicht geöffnet werden");
        return;
    }

    char trenner = '\0';
    char terminator = '\n';

    for(unsigned int i{}; i < karte.size(); ++i){
        string dif =  karte.at(i)->getType();
        double laenge = karte.at(i)->getLaengengrad();
        double breite = karte.at(i)->getBreitengrad();
        string name = karte.at(i)->getname();

        if(dif == "Adr"){
            string strasse = dynamic_cast<Adresse*>(karte[i])->getStrasse();
            string nummer = dynamic_cast<Adresse*>(karte[i])->getHausnummer();
            unsigned int post = dynamic_cast<Adresse*>(karte[i])->getPostleitzahl();
            string stadt = dynamic_cast<Adresse*>(karte[i])->getStadt();

            file_out << dif << trenner << laenge << trenner << breite << trenner << name << trenner << strasse << trenner << nummer << trenner << post << trenner << stadt << terminator;
        }
        if(dif == "PoI"){
            string kategorie = dynamic_cast<PoI*>(karte[i])->getKategorie();
            string bemerkung = dynamic_cast<PoI*>(karte[i])->getBemerkung();

            file_out << dif << trenner << laenge << trenner << breite << trenner << name << trenner << kategorie << trenner << bemerkung << terminator;
        }
    }

    file_out << "Liste" << graph.print_verbindungen() << "\n";

    file_out.close();
    QMessageBox::information(nullptr, "Ausgabe", "Erfolgreich exportiert");
}

void Navigation::importASCII(){
    if(!karte.empty()){
        QMessageBox::information(nullptr, "Fehlermeldung", "Orte können nur importiert werden, wenn die Karte noch leer ist");
        return;
    }

    char c{};
    std::ifstream datei;

    QInputDialog Qmyinput;
    QString QFilename = Qmyinput.getText(this,"Dateiname", "Dateiname mit Datepfad angeben");
    std::string filename = QFilename.toStdString(); //(/home/stud/Uni/Ablage_Test/export.txt)
    datei.open(filename, std::ios::in);

    if (!datei) { // Fehlerabfrage
        QMessageBox::information(nullptr, "Fehlermeldung", "Datei kann nicht geöffnet werden");
        return;
    }

    string dif;
    string tmp;
    string leerstring{};
    double laenge;
    double breite;
    string name;
    bool bdif = true;
    bool blaenge = false;
    bool bbreite = false;
    bool bname = false;
    bool next = false;
    bool bliste = false;
    bool bfirst = true;

    string kategorie;
    string bemerkung;

    bool bstrasse = true;
    bool bhaus = false;
    bool bpost = false;
    string strasse;
    string hausnummer;
    int post;
    string stadt;

    int id1;
    int id2;

    while (datei.eof() != true){
        datei.get(c);

        if (c == '\0' && bdif){
            dif = tmp;
            datei.get(c);
            tmp = leerstring;
            bdif = false;
            blaenge = true;
        }
        else if(c == '\0' && blaenge){
            std::locale::global(std::locale("en_US.UTF-8"));
            laenge = stod(tmp);
            datei.get(c);
            tmp = leerstring;
            blaenge = false;
            bbreite = true;
        }
        else if(c == '\0' && bbreite){
            std::locale::global(std::locale("en_US.UTF-8"));
            breite = stod(tmp);
            datei.get(c);
            tmp = leerstring;
            bbreite = false;
            bname = true;
        }
        else if(c == '\0' && bname){
            name = tmp;
            datei.get(c);
            tmp = leerstring;
            bname = false;
            next = true;
            bstrasse = true;
        }

        if(next && dif == "Adr"){
            if(c == '\n'){
                stadt = tmp;
                tmp = leerstring;
                next = false;
                bdif = true;
                Adresse* tmpadress = new Adresse(laenge,breite,strasse,hausnummer,post,stadt,name);
                karte.push_back(tmpadress);


                QDynamicButton *button = new QDynamicButton(this);

                button->setText(QString::fromStdString(name));

                laenge = berechnung_laenge(laenge);
                breite = berechnung_breite(breite);

                button->setGeometry(laenge,breite, button->width(), 20);

                button->show();

                connect(button, SIGNAL(clicked()), this, SLOT(slotGetNumber()));
                buttonvec.push_back(button);
            }
            else if(c == '\0' && bstrasse){
                strasse = tmp;
                tmp = leerstring;
                bstrasse = false;
                bhaus = true;
            }
            else if(c == '\0' && bhaus){
                hausnummer = tmp;
                tmp = leerstring;
                bhaus = false;
                bpost = true;
            }
            else if(c == '\0' && bpost){
                post = stoi(tmp);
                tmp = leerstring;
                bpost = false;
            }
            else{
                tmp = leerstring;
                tmp += c;
            }
        }

        else if(next && dif == "PoI"){
            if(c == '\n'){
                bemerkung = tmp;
                tmp = leerstring;
                next = false;
                bdif = true;
                PoI* tmppoi = new PoI(laenge,breite,kategorie,bemerkung,name);
                karte.push_back(tmppoi);

                QDynamicButton *button = new QDynamicButton(this);

                button->setText(QString::fromStdString(name));

                laenge = berechnung_laenge(laenge);
                breite = berechnung_breite(breite);

                button->setGeometry(laenge,breite, button->width(), 20);

                button->show();

                connect(button, SIGNAL(clicked()), this, SLOT(slotGetNumber()));
                buttonvec.push_back(button);
            }
            else if(c == '\0'){
                kategorie = tmp;
                tmp = leerstring;
            }
            else{
                tmp += c;
            }
        }

        else if(tmp == "Liste" || bliste){
            if(c == '\n'){
                break;
            }
            if(c == ','){
                id1 = stoi(tmp);
                tmp = leerstring;
            }
            else if(c == ';'){
                id2 = stoi(tmp);
                tmp = leerstring;
                graph.addEdge(id1,id2,karte.at(id1)->EntfernungBerechnen(karte.at(id2)));
            }
            else if(bfirst){
                bliste = true;
                tmp = leerstring;
                bfirst = false;
                tmp += c;
            }
            else{
                tmp += c;
            }
        }

        else {
            tmp += c;
        }
    }


    datei.close();

    QMessageBox::information(nullptr, "Ausgabe", "Erfolgreich importiert");

    ui->Ort1->show();
    ui->Ort2->show();
    ui->OrtLoeschen->show();
    ui->neuerOrt->show();
    ui->information->show();
    ui->alleOrte->show();
    ui->entfernung->show();
    ui->Routing->show();
    ui->export_2->show();
}

void Navigation::information(){
    bool ok;
    int index = ui->index2->text().toInt(&ok);
    if(!ok){
        QMessageBox::information(nullptr, "Fehlermeldung", "Kein Ort wurde ausgwählt");
    }

    else{
        string ausgabe = karte.at(index)->getname() + "\nLängengrad: " + std::to_string(karte.at(index)->getLaengengrad()) + "\nBreitengrad: " + std::to_string(karte.at(index)->getBreitengrad()) + "\n";
        if(karte.at(index)->getType() == "Adr"){
            string adresse = dynamic_cast<Adresse*>(karte[index])->getStrasse() + " ";
            adresse.append(dynamic_cast<Adresse*>(karte[index])->getHausnummer() + "\n");

            adresse.append(dynamic_cast<Adresse*>(karte[index])->getStadt() + " ");
            int postleitzahl= dynamic_cast<Adresse*>(karte[index])->getPostleitzahl();
            string postadresse = std::to_string(postleitzahl);
          adresse.append(postadresse);
            ausgabe.append(adresse);
        }
        else if(karte.at(index)->getType() == "PoI"){
            string poi = dynamic_cast<PoI*>(karte[index])->getKategorie() + ", ";
            poi.append(dynamic_cast<PoI*>(karte[index])->getBemerkung());

            ausgabe.append(poi);
        }

        ausgabe.append("\nVerbindungen:\n");

        std::vector<int> edges = graph.edges_from_source(index);
        for(unsigned int i{}; i < edges.size(); ++i){
            ausgabe.append(karte.at(edges.at(i))->getname() + ": ");
            ausgabe.append(std::to_string(karte.at(index)->EntfernungBerechnen(karte.at(edges.at(i)))) + " km\n");
        }

        QMessageBox::information(nullptr, "Ausgabe", QString::fromStdString(ausgabe));
    }

}

void Navigation::alleOrte(){
    //Ausgabe formatieren
    if(karte.empty()){
        QMessageBox::information(nullptr, "Fehlermeldung", "Keine Orte wurden angelegt");
    }
    else{
        string ausgabe = "ID |Typ  |Name          \n";
        for(unsigned int i{}; i < karte.size(); ++i){
            ausgabe.append(std::to_string(karte.at(i)->getId()) + "  | " + karte.at(i)->getType() + "  |" + karte.at(i)->getname() + '\n');
        }

        QMessageBox::information(nullptr, "Ausgabe", QString::fromStdString(ausgabe));
    }
}

void Navigation::entfernung(){
    bool ok, ok2;
    int index = ui->index2->text().toInt(&ok2);
    int index2 = ui->index1->text().toInt(&ok);
    if(!ok || !ok2){
        QMessageBox::information(nullptr, "Fehlermeldung", "Kein Ort wurde ausgwählt");
    }

    else{
        double entfernung = karte.at(index)->EntfernungBerechnen(karte.at(index2));
        string ausgabe = "Die Entfernung zwischen " + karte.at(index)->getname() + " und " + karte.at(index2)->getname() + " beträgt " + std::to_string(entfernung) + "km";
        QMessageBox::information(nullptr, "Ausgabe", QString::fromStdString(ausgabe));
    }
}

void Navigation::ortloeschen(){
    bool ok;
    int index = ui->index2->text().toInt(&ok);
    if(!ok){
        QMessageBox::information(nullptr, "Fehlermeldung", "Kein Ort wurde ausgwählt");
    }
    else{
        delete karte.at(index);
        karte.erase(karte.begin() + index);

        QDynamicButton *button = buttonvec.at(index);
        button->hide();
        delete buttonvec.at(index);
        buttonvec.erase(buttonvec.begin() + index);

        graph.removeVertex(index);
    }
}

//abfrage wohin neue Orte verbunden werden
//vector<int> dijkstra(int source, int destination)

void Navigation::routing(){
    bool ok, ok2;
    int index = ui->index2->text().toInt(&ok2);
    int index2 = ui->index1->text().toInt(&ok);
    if(!ok || !ok2){
        QMessageBox::information(nullptr, "Fehlermeldung", "Kein Ort wurde ausgwählt");
    }

    string ausgabe;
    vector<double>shortest = graph.dijkstra(index, index2); //kürzeste Verbindung der beiden Orte wird ermittelt
    vector<int>path = graph.dijkstraShortestPath(index, index2); //kürzester Weg zwischen zwei Knoten wird ermittelt

    vector<double> abstaende ;
    for(int i = 0 ; i < path.size() -1; i++){
        double ergebnis = karte.at(path.at(i))->EntfernungBerechnen(karte.at(path.at(i+1)));
        abstaende.push_back(ergebnis);
    }

    for (int i{}; i < path.size(); ++i) {
        ausgabe.append(karte.at(path.at(i))->getname());
        if(i < path.size()-1){
            ausgabe.append(" (" + std::to_string(abstaende.at(i)));
        }
        if (i != path.size() -1)
            ausgabe.append(") -> ");
    }

    ausgabe.append("\nKürzester Weg von " + karte.at(index)->getname() + " nach " + karte.at(index2)->getname() + " = " + std::to_string(shortest[index2]) + " km");

    QMessageBox::information(nullptr, "Ausgabe", QString::fromStdString(ausgabe)); //+ km
}
