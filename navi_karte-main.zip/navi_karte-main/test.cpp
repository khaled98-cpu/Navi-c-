#include "test.h"

Test::Test(QObject *parent) : QObject(parent)
{

}

void Test::test_saarbruecken_cottbus(){
    PoI* Saarbrücken = new PoI(6.996379,49.234262,"Stadt","Hauptstadt vom Saarland","Saarbrücken");
    PoI* Cottbus = new PoI(14.3357307,51.7567447,"Satdt","Satdt in Brandenburg","Cottbus");

    double entfernung = Saarbrücken->EntfernungBerechnen(Cottbus);

    // Entfernung aus dem Internet = 590.55 km
    double expected = 590.55;

    // +/- 5% - Test
    double percent = expected * 0.05;
    double minimum = expected - percent;
    double maximum = expected + percent;

    QVERIFY(entfernung >= minimum && entfernung <= maximum);
}

void Test::test_kiel_muenchen(){
    PoI* Kiel = new PoI(10.135555,54.3227085,"Stadt","Hauptstadt von Schleswig-Holstein","Kiel");
    PoI* München = new PoI(11.5753822,48.1371079,"Stadt","Hauptstadt in Bayern","München");

    double entfernung = Kiel->EntfernungBerechnen(München);

    // Entfernung aus dem Internet = 590.55 km
    double expected = 693.14;

    // +/- 5% - Test
    double percent = expected * 0.05;
    double minimum = expected - percent;
    double maximum = expected + percent;

    QVERIFY(entfernung >= minimum && entfernung <= maximum);
}

void Test::test_duesseldorf_chemnitz(){
    PoI* Düsseldorf = new PoI(6.7763137,51.2254018,"Stadt","Stadt in Nordrein-Westfalen","Düsseldorf");
    PoI* Chemnitz = new PoI(12.9252977,50.8322608,"Stadt","Stadt in Sachsen","Chemnitz");

    double entfernung = Düsseldorf->EntfernungBerechnen(Chemnitz);

    double expected = 429.44;

    double percent = expected * 0.05;
    double minimum = expected - percent;
    double maximum = expected + percent;

    QVERIFY(entfernung >= minimum && entfernung <= maximum);
}

void Test::test_bremen_augsburg(){
    PoI* Bremen = new PoI(8.8071646,53.0758196,"Stadt","Hauptstadt von Bremen","Bremen");
    PoI* Augsburg = new PoI(10.8986972,48.3668041,"Stadt","Stadt in Bayern","Augsburg");

    double entfernung = Bremen->EntfernungBerechnen(Augsburg);

    double expected = 544.25;

    double percent = expected * 0.05;
    double minimum = expected - percent;
    double maximum = expected + percent;

    QVERIFY(entfernung >= minimum && entfernung <= maximum);
}


//void Test::test(){


//    Navigation w;
//    w.show();
//    QTest::mouseClick(w.getui()->import_2, Qt::LeftButton);
//    QWidget* peter = QApplication::activeModalWidget();
//    QInputDialog* sabine = dynamic_cast<QInputDialog*>(peter);
//    sabine->setTextValue("export.txt");
//    QTest::keyPress(sabine, Qt::Key_Enter);
//    //QWidgetList liste = QApplication::topLevelWidgets();
//}
