#include "graph.h"

Graph::Graph(int vertices) : numVertices(vertices) {
    adjList.resize(numVertices);
}

void Graph::addEdge(int source, int destination, double weight) { // Funktion zum Hinzufügen einer Kante zum Graphen
    Edge edge;
    edge.destination = destination;
    edge.weight = weight;

    // Kante von source zu destination hinzufügen
    adjList[source].push_back(edge);

    // Kante von destination zu source hinzufügen
    edge.destination = source;
    adjList[destination].push_back(edge);
}

void Graph::printGraph() { // Funktion zum Ausgeben des Graphen
    for (int i = 0; i < numVertices; i++) {
        cout << "Adjazenzliste des Knotens " << i << ": ";
        for (const Edge& edge : adjList[i]) {
            cout << "(" << edge.destination << ", " << edge.weight << ") ";
        }
        cout << endl;
    }
}

string Graph::print_verbindungen(){ //alle Verbindungen zwischen Orten
    string result;
    for(unsigned int i{}; i < numVertices; ++i){
        for(const Edge& edge : adjList[i]){
            if(edge.destination >= i){
                result.append(std::to_string(i) + "," + std::to_string(edge.destination) + ";");
                //result.append("(" + std::to_string(i) + "," + std::to_string(edge.destination) + ") ");
//                cout << "(" << i << "," << edge.destination << ") ";
            }
        }
    }
    return result;
}

void Graph::print_verbindung(int source){ //print verbindung von bestimmtem Knoten mit Gewichtung
    for (const Edge& edge : adjList[source]) {
        cout << "(" << edge.destination << ", " << edge.weight << ") ";
    }
}

std::vector<int> Graph::edges_from_source(int source){ // alle Verbindungen, die der Ort "source" hat
    std::vector<int> result;
    for (const Edge& edge : adjList[source]){
        result.push_back(edge.destination);
    }
    return result;
}

void Graph::resizeGraph(int newVertices) { // Funktion zum Ändern der Größe des Graphen
    // Wenn die Anzahl der Knoten zunimmt, füge neue leere Adjazenzlisten hinzu
    if (newVertices > numVertices) {
        adjList.resize(newVertices);
        numVertices = newVertices;
    }
    // Wenn die Anzahl der Knoten abnimmt, entferne die überflüssigen Adjazenzlisten
    else if (newVertices < numVertices) {
        adjList.resize(newVertices);
        numVertices = newVertices;

        // Entferne alle Kanten, die zu Knoten außerhalb des neuen Bereichs führen
        for (int i = 0; i < numVertices; i++) {
            vector<Edge>& edges = adjList[i];
            edges.erase(
                remove_if(edges.begin(), edges.end(), [&](const Edge& edge) {
                return edge.destination >= numVertices;
            }),
            edges.end());
         }
    }
}

void Graph::removeVertex(int vertex) { // Funktion zum Löschen eines Knotens im Graphen
    for (int i = 0; i < numVertices; i++) { // Entferne alle Kanten, die mit diesem Knoten verbunden sind
        vector<Edge>& edges = adjList[i];
        edges.erase(
            remove_if(edges.begin(), edges.end(), [&](const Edge& edge) {
            return edge.destination == vertex;
        }),
        edges.end());
    }
    adjList[vertex].clear();
}
