#ifndef ADRESSE_H
#define ADRESSE_H

#include "ort.h"

class Adresse: public Ort
{
private:
    string strasse;
    string hausnummer;
    int postleitzahl;
    string stadt;
    string name;
public:
    Adresse();
    ~Adresse();
    Adresse(double,double, string, string, int, string, string);
    Ort* createAdresse();
    string getStrasse()const;
    string getHausnummer()const;
    int getPostleitzahl()const;
    virtual string getStadt()const;
    string getname() override {return name;};
    string anzeigen() const override;
    void setType(char type)override;
    string getType()const override {return "Adr";};
    string getparameters() override;
};

#endif // ADRESSE_H
