#include "adresse.h"

Adresse::Adresse()
    :Ort(),strasse{"strasse"},hausnummer{"hausnummer"},postleitzahl{0},stadt{"stadt"}
{}

Adresse::Adresse(double laengengrad, double breitengrad, string strasse, string hausnummer, int postleitzahl,string stadt, string name)
    :Ort(laengengrad,breitengrad), strasse{strasse},hausnummer{hausnummer},postleitzahl{postleitzahl},stadt{stadt},name{name}
{}

Adresse::~Adresse(){

}
void Adresse::setType(char type){
    Ort::setType(type);
}

Ort* Adresse::createAdresse(){
    double laengengrad{},breitengrad{};
    string strasse{},stadt{},hausnummer;
    int postleitzahl{};

    cout<<"laengengrad eingeben (Bsp. \"8.6625808\"):"<<endl;
    cin>>laengengrad;
    cout<<"breitengrad eingeben (Bsp. \"50.1066539\"):"<<endl;
    cin>>breitengrad;

    cin.ignore();
    cout<<"strasse eingeben"<<endl;
    getline(cin,strasse);

    cout<<"hausnummer eingeben"<<endl;
    cin>>hausnummer;

    cout<<"postleitzahl eingeben"<<endl;
    cin>>postleitzahl;
    while(postleitzahl < 1){
        cout<<"Ungueltige id. Erneut eingeben"<<endl;
        cin>>postleitzahl;
    }

    cout<<"stadt eingeben"<<endl;
    cin.ignore();
    getline(cin,stadt);

    Adresse* a = new Adresse(laengengrad,breitengrad,strasse,hausnummer,postleitzahl,stadt, name);
    a->setType('a');
    return a;
}

string Adresse::anzeigen() const {
    string adresseanzeigen = name + "    | " + std::to_string(Ort::getBreitengrad()) + "    | " + std::to_string(Ort::getLaengengrad()) + "        | " +  strasse + " " + hausnummer + ", " + std::to_string(postleitzahl) + " " + stadt + "\n";
    return adresseanzeigen;
}

string Adresse::getStrasse()const{
    return strasse;
}

string Adresse::getHausnummer()const{
    return hausnummer;
}

int Adresse::getPostleitzahl()const{
    return postleitzahl;
}

string Adresse::getStadt()const{
    return stadt;
}

string Adresse::getparameters(){
    return this->strasse + " " + this->hausnummer + ", " + std::to_string(this->postleitzahl) + " " + this->stadt;
}
