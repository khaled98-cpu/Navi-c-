#include "ort.h"

static int next_id = -7;

Ort::Ort()
    :id{0}, laengengrad{0.0},breitengrad{0.0}
{}

Ort::Ort(double laengengrad, double breitengrad)
    :id{next_id++}, laengengrad{laengengrad},breitengrad{breitengrad}
{}

Ort::~Ort(){

}

void Ort::setType(char type){
    this->type=type;
}

int Ort::getId()const{
    return id;
}

string Ort::getType() const{
    return type;
}
double Ort::getLaengengrad()const{
    return laengengrad;
}

double Ort::getBreitengrad()const{
    return breitengrad;
}

double inRadUmwandeln(double grad){
    return grad*pi/180;
}


double Ort::EntfernungBerechnen(const Ort* Ort1){
    double entfernung{};
    double lon1 = inRadUmwandeln(this->getLaengengrad());  // laengengrad in Radian
    double lat1 = inRadUmwandeln(this->getBreitengrad());  // breitengrad in Radian

    double lon2 = inRadUmwandeln(Ort1->getLaengengrad());  // laengengrad in Radian
    double lat2 = inRadUmwandeln(Ort1->getBreitengrad());  // breitengrad in Radian

    double a = sin((lat2-lat1)/2) * sin((lat2-lat1)/2);
    double b = sin((lon2-lon1)/2) * sin((lon2-lon1)/2);
    entfernung = erd_radius * 2 * asin(sqrt(a + cos(lat1) * cos(lat2) * b));
    return entfernung;
}

string Ort::anzeigen() const{
    return "Ort";
}
