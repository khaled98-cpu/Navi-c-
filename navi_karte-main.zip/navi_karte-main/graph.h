#ifndef GRAPH_H
#define GRAPH_H

#include<queue>
#include "ort.h"

struct Edge {
    int destination;
    double weight;
};

// Klasse für die Graphenimplementierung
class Graph {
    int numVertices; // Anzahl der Knoten im Graphen
    vector<vector<Edge>> adjList; // Adjazenzliste

public:
    Graph(int vertices);
    void addEdge(int source, int destination, double weight);
    void printGraph();
    string print_verbindungen();
    void print_verbindung(int source);
    std::vector<int> edges_from_source(int source);
    void resizeGraph(int newVertices);
    void removeVertex(int vertex);

    std::vector<double> dijkstra(int source, int destination){
        std::vector<double> distance(numVertices, std::numeric_limits<double>::infinity());
        std::vector<int> previous(numVertices, -1);
        std::priority_queue<std::pair<double, int>, std::vector<std::pair<double, int>>, std::greater<std::pair<double, int>>> pq;

        distance[source] = 0.0;
        pq.push({0.0, source});

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();

            for (const Edge& edge : adjList[u]) {
                int v = edge.destination;
                double weight = edge.weight;

                double newDistance = distance[u] + weight;
                if (newDistance < distance[v]) {
                    distance[v] = newDistance;
                    previous[v] = u;
                    pq.push({newDistance, v});
                }
            }
        }
        return distance;
    }

    std::vector<int> dijkstraShortestPath(int source, int destination) { //Rückgabe welche Städte
            std::vector<double> distance(numVertices, std::numeric_limits<double>::infinity());
            std::vector<int> previous(numVertices, -1);
            std::priority_queue<std::pair<double, int>, std::vector<std::pair<double, int>>, std::greater<std::pair<double, int>>> pq;

            distance[source] = 0.0;
            pq.push({0.0, source});

            while (!pq.empty()) {
                int u = pq.top().second;
                pq.pop();

                for (const Edge& edge : adjList[u]) {
                    int v = edge.destination;
                    double weight = edge.weight;

                    double newDistance = distance[u] + weight;
                    if (newDistance < distance[v]) {
                        distance[v] = newDistance;
                        previous[v] = u;
                        pq.push({newDistance, v});
                    }
                }
            }

            std::vector<int> path;
            int current = destination;
            while (current != -1) {
                path.push_back(current);
                current = previous[current];
            }
            std::reverse(path.begin(), path.end());

            return path;
        }


    void removeAllConnections(int source);

    void printGraph_bedingt(){
        cout << "Bedingte Ausgabe AdjazenzListe:" << std::endl;

        for(unsigned int i{}; i < numVertices; ++i){
            cout << "Adjazenzliste des Knotens " << i << ": ";
            for(const Edge& edge : adjList[i]){
                if(edge.destination >= i){
                    cout << "(" << edge.destination << "," << edge.weight << ") ";
                }
            }
            cout << endl;
        }
    }



    bool connectedEdges(int source, int destination){ // gibt kürzesten Weg an??
        if(adjList[source].empty()){
            return false;
        }

        for(int i = 0; i < numVertices; i++){
            for(const Edge& edge : adjList[i]){
                if(edge.destination == destination){
                    std::cout << edge.destination;
                    return true;
                }
            }
        }
        return false;
    }

//    vector<double> rekonstruktion_weg(int index2, vector<double> shortestDistances) {
//        vector<double> weg;
//        int index = index2;
//        weg.push_back(index);

//        while (shortestDistances[index] != 0) {
//            for (int i = 0; i < numVertices; ++i) {
//                if (adjList[index][i].destination == weg.back() && shortestDistances[i] + adjList[i][index].weight == shortestDistances[index]) {
//                    weg.push_back(i);
//                    index = i;
//                    break;
//                }
//            }
//        }

//        reverse(weg.begin(), weg.end());

//        return weg;
//    }

//    vector<double> rekonstruktion_weg(int index2, vector<double> shortestDistances){ //problem??
//        vector<double> path;
//            int current = index2;
//            path.push_back(current);
//            int index = sizeof index;
//            while (current != index) {
//                for (const Edge& edge : adjList[current]) {
//                if (shortestDistances[current] == shortestDistances[edge.destination] + edge.weight) {
//                    current = edge.destination;
//                    path.push_back(current);
//                    }
//                }
//            }
//            return path;
//    }

    // Funktion zum Durchführen des Dijkstra-Algorithmus
//        vector<double> dijkstra(int source, int destination) {
//            // Initialisierung
//            vector<double> distance(numVertices, numeric_limits<int>::max());
//            distance[source] = 0;
//            vector<bool> visited(numVertices, false);
//            priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<double, double>>> pq;
//            pq.push({0, source});

//            // Dijkstra-Algorithmus
//            while (!pq.empty()) {
//                int u = pq.top().second;
//                pq.pop();

//                if (visited[u])
//                    continue;

//                visited[u] = true;

//                for (const Edge& edge : adjList[u]) {
//                    int v = edge.destination;
//                    int weight = edge.weight;

//                    if (!visited[v] && distance[u] + weight < distance[v]) {
//                        distance[v] = distance[u] + weight;
//                        pq.push({distance[v], v});
//                    }
//                }
//            }

//            return distance;
//        }

};



// Implementieren Sie eine Funktion mit der geprüft werden kann ob zwei Orte miteinander verbunden sind.

#endif // GRAPH_H
